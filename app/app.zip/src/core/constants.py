VIDEO_EXTENSIONS = {'mp4', 'mkv', 'webm', 'mov', 'flv', 'avi', 'gif'}
AUDIO_EXTENSIONS = {'m4a', 'mp3', 'ogg', 'opus', 'flac', 'wav'}
SINGLE_STREAM_AUDIO_CONTAINERS = {'.mp3', '.wav', '.flac', '.ac3'}

# Dominios que funcionan bien con extracción plana (Modo Rápido)
FAST_MODE_SUPPORTED_DOMAINS = ["youtube.com", "youtu.be", "soundcloud.com", "x.com", "twitter.com", 
"instagram.com", "tiktok.com", "reddit.com", "facebook.com", "tumblr.com", "vimeo.com", 
"dailymotion.com", "bandcamp.com", "twitch.tv", "smugmug.com", "flickr.com", "metacafe.com", "vimeo.com", 
"archive.org", "archive.org", "archive.org", "archive.org", "archive.org", "archive.org", "archive.org"]

FORMAT_MUXER_MAP = {
    ".m4a": "mp4",
    ".wma": "asf"
}

LANG_CODE_MAP = {
    "es": "Español",
    "es-419": "Español (Latinoamérica)",
    "es-es": "Español (España)",
    "es_la": "Español (Latinoamérica)", 
    "es-us": "Español (EE.UU.)",
    "en": "Inglés",
    "en-us": "Inglés (EE.UU.)",
    "en-gb": "Inglés (Reino Unido)",
    "en-orig": "Inglés (Original)",
    "ja": "Japonés",
    "fr": "Francés",
    "de": "Alemán",
    "it": "Italiano",
    "pt": "Portugués",
    "pt-br": "Portugués (Brasil)",
    "pt-pt": "Portugués (Portugal)",
    "ru": "Ruso",
    "zh": "Chino",
    "zh-cn": "Chino (Simplificado)",
    "zh-tw": "Chino (Tradicional)",
    "zh-hans": "Chino (Simplificado)", 
    "zh-hant": "Chino (Tradicional)", 
    "ko": "Coreano",
    "ar": "Árabe",
    "hi": "Hindi",
    "iw": "Hebreo (código antiguo)", 
    "he": "Hebreo",
    "fil": "Filipino", 
    "aa": "Afar",
    "ab": "Abjasio",
    "ae": "Avéstico",
    "af": "Afrikáans",
    "ak": "Akán",
    "am": "Amárico",
    "an": "Aragonés",
    "as": "Asamés",
    "av": "Avar",
    "ay": "Aimara",
    "az": "Azerí",
    "ba": "Baskir",
    "be": "Bielorruso",
    "bg": "Búlgaro",
    "bh": "Bhojpuri",
    "bho": "Bhojpuri", 
    "bi": "Bislama",
    "bm": "Bambara",
    "bn": "Bengalí",
    "bo": "Tibetano",
    "br": "Bretón",
    "bs": "Bosnio",
    "ca": "Catalán",
    "ce": "Checheno",
    "ceb": "Cebuano", 
    "ch": "Chamorro",
    "co": "Corso",
    "cr": "Cree",
    "cs": "Checo",
    "cu": "Eslavo eclesiástico",
    "cv": "Chuvash",
    "cy": "Galés",
    "da": "Danés",
    "dv": "Divehi",
    "dz": "Dzongkha",
    "ee": "Ewe",
    "el": "Griego",
    "eo": "Esperanto",
    "et": "Estonio",
    "eu": "Euskera",
    "fa": "Persa",
    "ff": "Fula",
    "fi": "Finlandés",
    "fj": "Fiyiano",
    "fo": "Feroés",
    "fy": "Frisón occidental",
    "ga": "Irlandés",
    "gd": "Gaélico escocés",
    "gl": "Gallego",
    "gn": "Guaraní",
    "gu": "Guyaratí",
    "gv": "Manés",
    "ha": "Hausa",
    "ht": "Haitiano",
    "hu": "Húngaro",
    "hy": "Armenio",
    "hz": "Herero",
    "ia": "Interlingua",
    "id": "Indonesio",
    "ie": "Interlingue",
    "ig": "Igbo",
    "ii": "Yi de Sichuán",
    "ik": "Inupiaq",
    "io": "Ido",
    "is": "Islandés",
    "iu": "Inuktitut",
    "jv": "Javanés",
    "ka": "Georgiano",
    "kg": "Kongo",
    "ki": "Kikuyu",
    "kj": "Kuanyama",
    "kk": "Kazajo",
    "kl": "Groenlandés",
    "km": "Jemer",
    "kn": "Canarés",
    "kr": "Kanuri",
    "ks": "Cachemiro",
    "ku": "Kurdo",
    "kv": "Komi",
    "kw": "Córnico",
    "ky": "Kirguís",
    "la": "Latín",
    "lb": "Luxemburgués",
    "lg": "Ganda",
    "li": "Limburgués",
    "ln": "Lingala",
    "lo": "Lao",
    "lt": "Lituano",
    "lu": "Luba-katanga",
    "lv": "Letón",
    "mg": "Malgache",
    "mh": "Marshalés",
    "mi": "Maorí",
    "mk": "Macedonio",
    "ml": "Malayalam",
    "mn": "Mongol",
    "mr": "Maratí",
    "ms": "Malayo",
    "mt": "Maltés",
    "my": "Birmano",
    "na": "Nauruano",
    "nb": "Noruego bokmål",
    "nd": "Ndebele del norte",
    "ne": "Nepalí",
    "ng": "Ndonga",
    "nl": "Neerlandés",
    "nn": "Noruego nynorsk",
    "no": "Noruego",
    "nr": "Ndebele del sur",
    "nv": "Navajo",
    "ny": "Chichewa",
    "oc": "Occitano",
    "oj": "Ojibwa",
    "om": "Oromo",
    "or": "Oriya",
    "os": "Osético",
    "pa": "Panyabí",
    "pi": "Pali",
    "pl": "Polaco",
    "ps": "Pastún",
    "qu": "Quechua",
    "rm": "Romanche",
    "rn": "Kirundi",
    "ro": "Rumano",
    "rw": "Kinyarwanda",
    "sa": "Sánscrito",
    "sc": "Sardo",
    "sd": "Sindhi",
    "se": "Sami septentrional",
    "sg": "Sango",
    "si": "Cingalés",
    "sk": "Eslovaco",
    "sl": "Esloveno",
    "sm": "Samoano",
    "sn": "Shona",
    "so": "Somalí",
    "sq": "Albanés",
    "sr": "Serbio",
    "ss": "Suazi",
    "st": "Sesotho",
    "su": "Sundanés",
    "sv": "Sueco",
    "sw": "Suajili",
    "ta": "Tamil",
    "te": "Telugu",
    "tg": "Tayiko",
    "th": "Tailandés",
    "ti": "Tigriña",
    "tk": "Turcomano",
    "tl": "Tagalo",
    "tn": "Setsuana",
    "to": "Tongano",
    "tr": "Turco",
    "ts": "Tsonga",
    "tt": "Tártaro",
    "tw": "Twi",
    "ty": "Tahitiano",
    "ug": "Uigur",
    "uk": "Ucraniano",
    "ur": "Urdu",
    "uz": "Uzbeko",
    "ve": "Venda",
    "vi": "Vietnamita",
    "vo": "Volapük",
    "wa": "Valón",
    "wo": "Wolof",
    "xh": "Xhosa",
    "yi": "Yidis",
    "yo": "Yoruba",
    "za": "Zhuang",
    "zu": "Zulú",
    "und": "No especificado",
    "alb-al": "Albanés (Albania)",
    "ara-sa": "Árabe (Arabia Saudita)",
    "aze-az": "Azerí (Azerbaiyán)",
    "ben-bd": "Bengalí (Bangladesh)",
    "bul-bg": "Búlgaro (Bulgaria)",
    "cat-es": "Catalán (España)",
    "ces-cz": "Checo (República Checa)",
    "cmn-hans-cn": "Chino Mandarín (Simplificado, China)",
    "cmn-hant-cn": "Chino Mandarín (Tradicional, China)",
    "crs": "Francés criollo seselwa",
    "dan-dk": "Danés (Dinamarca)",
    "deu-de": "Alemán (Alemania)",
    "ell-gr": "Griego (Grecia)",
    "est-ee": "Estonio (Estonia)",
    "fil-ph": "Filipino (Filipinas)",
    "fin-fi": "Finlandés (Finlandia)",
    "fra-fr": "Francés (Francia)",
    "gaa": "Ga",
    "gle-ie": "Irlandés (Irlanda)",
    "haw": "Hawaiano",
    "heb-il": "Hebreo (Israel)",
    "hin-in": "Hindi (India)",
    "hmn": "Hmong",
    "hrv-hr": "Croata (Croacia)",
    "hun-hu": "Húngaro (Hungría)",
    "ind-id": "Indonesio (Indonesia)",
    "isl-is": "Islandés (Islandia)",
    "ita-it": "Italiano (Italia)",
    "jav-id": "Javanés (Indonesia)",
    "jpn-jp": "Japonés (Japón)",
    "kaz-kz": "Kazajo (Kazajistán)",
    "kha": "Khasi",
    "khm-kh": "Jemer (Camboya)",
    "kor-kr": "Coreano (Corea del Sur)",
    "kri": "Krio",
    "lav-lv": "Letón (Letonia)",
    "lit-lt": "Lituano (Lituania)",
    "lua": "Luba-Lulua",
    "luo": "Luo",
    "mfe": "Morisyen",
    "msa-my": "Malayo (Malasia)",
    "mya-mm": "Birmano (Myanmar)",
    "new": "Newari",
    "nld-nl": "Neerlandés (Países Bajos)",
    "nob-no": "Noruego Bokmål (Noruega)",
    "nso": "Sotho del norte",
    "pam": "Pampanga",
    "pol-pl": "Polaco (Polonia)",
    "por-pt": "Portugués (Portugal)",
    "ron-ro": "Rumano (Rumania)",
    "rus-ru": "Ruso (Rusia)",
    "slk-sk": "Eslovaco (Eslovaquia)",
    "slv-si": "Esloveno (Eslovenia)",
    "spa-es": "Español (España)",
    "swa-sw": "Suajili", 
    "swe-se": "Sueco (Suecia)",
    "tha-th": "Tailandés (Tailandia)",
    "tum": "Tumbuka",
    "tur-tr": "Turco (Turquía)",
    "ukr-ua": "Ucraniano (Ucrania)",
    "urd-pk": "Urdu (Pakistán)",
    "uzb-uz": "Uzbeko (Uzbekistán)",
    "vie-vn": "Vietnamita (Vietnam)",
    "war": "Waray",
    "alb": "Albanés",
    "ara": "Árabe",
    "aze": "Azerí",
    "ben": "Bengalí",
    "bul": "Búlgaro",
    "cat": "Catalán",
    "ces": "Checo",
    "cmn": "Chino Mandarín",
    "dan": "Danés",
    "deu": "Alemán",
    "ell": "Griego",
    "est": "Estonio",
    "fin": "Finlandés",
    "fra": "Francés",
    "gle": "Irlandés",
    "heb": "Hebreo",
    "hin": "Hindi",
    "hrv": "Croata",
    "hun": "Húngaro",
    "ind": "Indonesio",
    "isl": "Islandés",
    "ita": "Italiano",
    "jav": "Javanés",
    "jpn": "Japonés",
    "kaz": "Kazajo",
    "khm": "Jemer",
    "kor": "Coreano",
    "lav": "Letón",
    "lit": "Lituano",
    "msa": "Malayo",
    "mya": "Birmano",
    "nld": "Neerlandés",
    "nob": "Noruego Bokmål",
    "pol": "Polaco",
    "por": "Portugués",
    "ron": "Rumano",
    "rus": "Ruso",
    "slk": "Eslovaco",
    "slv": "Esloveno",
    "spa": "Español",
    "swe": "Sueco",
    "swa": "Suajili",
    "tha": "Tailandés",
    "tur": "Turco",
    "ukr": "Ucraniano",
    "urd": "Urdu",
    "uzb": "Uzbeko",
    "vie": "Vietnamita",
}

LANGUAGE_ORDER = {
    'en': 0,       # Inglés (General)
    'en-us': 1,    # Inglés EE.UU.
    'en-gb': 2,    # Inglés UK
    'en-orig': 3,  # Inglés (Original)
    'es': 4,       # Español (General)
    'es-419': 5,   # Español LATAM
    'es-es': 6,    # Español España
    'es_la': 7,    # Español (Latinoamérica)
    'es-us': 8,    # Español (EE.UU.)
    'ja': 9,       # Japonés 
    'fr': 10,       # Francés 
    'de': 11,      # Alemán 
    'pt': 12,      # Portugués
    'it': 13,      # Italiano
    'zh': 14,      # Chino
    'ko': 15,      # Coreano
    'ru': 16,      # Ruso
    'ar': 17,      # Árabe
    'hi': 18,      # Hindi
    'vi': 19,      # Vietnamita
    'th': 20,      # Tailandés
    'pl': 21,      # Polaco
    'id': 22,      # Indonesio
    'tr': 23,      # Turco
    'bn': 24,      # Bengalí
    'ta': 25,      # Tamil
    'te': 26,      # Telugu
    'pa': 27,      # Punjabi
    'mr': 28,      # Marathi
    'ca': 29,      # Catalán
    'gl': 30,      # Gallego
    'eu': 31,      # Euskera
    'und': 32,     # Indefinido
}

DEFAULT_PRIORITY = 99 

EDITOR_FRIENDLY_CRITERIA = {
    "compatible_vcodecs": [
        "h264", "avc1",  # H.264
        "hevc", "h265",  # H.265
        "prores",        # Apple ProRes
        "dnxhd", "dnxhr", # Avid DNxHD/HR
        "cfhd",          # GoPro CineForm
        "mpeg2video",    
        "dvvideo"        # Formato de cámaras MiniDV
    ],
    "compatible_acodecs": ["aac", "mp4a", "pcm_s16le", "pcm_s24le", "mp3", "ac3"],
    "compatible_exts": ["mp4", "mov", "mxf", "mts", "m2ts", "avi"],
}

COMPATIBILITY_RULES = {
    ".gif": {
        "video": ["gif"],  
        "audio": []       
    },
    ".mov": {
        "video": ["prores_aw", "prores_ks", "dnxhd", "cfhd", "qtrle", "hap", "h264_videotoolbox", "libx264"],
        "audio": ["pcm_s16le", "pcm_s24le", "alac"]
    },
    ".mp4": {
        "video": ["libx264", "libx265", "h264_nvenc", "hevc_nvenc", "h264_amf", "hevc_amf", "av1_nvenc", "av1_amf", "h264_qsv", "hevc_qsv", "av1_qsv", "vp9_qsv"],
        "audio": ["aac", "mp3", "ac3", "opus"]
    },
    ".mkv": {
        "video": ["libx264", "libx265", "libvpx", "libvpx-vp9", "libaom-av1", "h264_nvenc", "hevc_nvenc", "av1_nvenc"],
        "audio": ["aac", "mp3", "opus", "flac", "libvorbis", "ac3", "pcm_s16le"]
    },
    ".webm": { "video": ["libvpx", "libvpx-vp9", "libaom-av1"], "audio": ["libopus", "libvorbis"] },
    ".ogg": { "video": [], "audio": ["libvorbis", "libopus"] },
    ".ac3": { "video": [], "audio": ["ac3"] },
    ".wma": { "video": [], "audio": ["wmav2"] },
    ".mxf": { "video": ["mpeg2video", "dnxhd"], "audio": ["pcm_s16le", "pcm_s24le"] },
    ".flac": { "video": [], "audio": ["flac"] },
    ".mp3": { "video": [], "audio": ["libmp3lame"] },
    ".m4a": { "video": [], "audio": ["aac", "alac"] },
    ".opus": { "video": [], "audio": ["libopus"] },
    ".wav": { "video": [], "audio": ["pcm_s16le", "pcm_s24le"] }
}

# --- NUEVO: Definir formatos RAW ---
IMAGE_RAW_FORMATS = {".CR2", ".DNG", ".ARW", ".NEF", ".ORF", ".RW2", ".SR2", ".RAF", ".CR3", ".PEF"}
# --- CONSTANTES DE HERRAMIENTAS DE IMAGEN ---

# Actualizar los formatos de entrada permitidos sumando los RAW
IMAGE_INPUT_FORMATS = {".svg", ".eps", ".ai", ".pdf", ".ps"}.union(IMAGE_RAW_FORMATS)
IMAGE_EXPORT_FORMATS = ["PNG", "JPG", "JPEG", "WEBP", "AVIF", "BMP", "PDF", "TIFF"]

# Agrupar formatos por tipo para mejor manejo en la lógica y la UI
IMAGE_RASTER_FORMATS = {"PNG", "JPG", "JPEG", "WEBP", "BMP", "TIFF", "AVIF"}
IMAGE_VECTOR_FORMATS = {"PDF"} 
FORMATS_WITH_TRANSPARENCY = {"PNG", "WEBP", "TIFF", "ICO", "PDF", "AVIF"}

# DPI por defecto para rasterización (de PDF, SVG, etc.)
DEFAULT_RASTER_DPI = 300

# Límites de seguridad para escalado
MAX_RECOMMENDED_DPI = 600
MAX_SAFE_DIMENSION = 8192  # Píxeles (8K)
CRITICAL_DPI_THRESHOLD = 1200
CRITICAL_DIMENSION_THRESHOLD = 16384  # 16K

# Métodos de interpolación para escalado de raster
INTERPOLATION_METHODS = {
    "Lanczos (Mejor Calidad)": "LANCZOS",
    "Bicúbico (Rápido)": "BICUBIC", 
    "Bilineal (Muy Rápido)": "BILINEAR",
    "Nearest (Pixelado)": "NEAREST"
}

# --- CONSTANTES DE PLACEHOLDERS (IA) ---
AI_FAMILY_HOLDER = "Seleccione la familia..."
AI_ENGINE_HOLDER = "Seleccione el motor..."
AI_MODEL_HOLDER = "Seleccione el modelo..."

# Opciones de Canvas
CANVAS_OPTIONS = [
    "Sin ajuste",
    "Añadir Margen Externo",
    "Instagram Post (1080×1080)",
    "Instagram Story (1080×1920)",
    "YouTube Thumbnail (1280×720)",
    "Twitter Header (1500×500)",
    "Facebook Cover (820×312)",
    "Personalizado..."
]

# Mapeo de presets fijos
CANVAS_PRESET_SIZES = {
    "Instagram Post (1080×1080)": (1080, 1080),
    "Instagram Story (1080×1920)": (1080, 1920),
    "YouTube Thumbnail (1280×720)": (1280, 720),
    "Twitter Header (1500×500)": (1500, 500),
    "Facebook Cover (820×312)": (820, 312)
}

# Posiciones para el contenido en el canvas
CANVAS_POSITIONS = [
    "Centro",
    "Arriba Izquierda",
    "Arriba Centro",
    "Arriba Derecha",
    "Centro Izquierda",
    "Centro Derecha",
    "Abajo Izquierda",
    "Abajo Centro",
    "Abajo Derecha"
]

# Modos de manejo cuando la imagen excede el canvas
CANVAS_OVERFLOW_MODES = [
    "Reducir hasta que quepa",           
    "Centrar (puede recortar)",
    "Recortar al canvas",
    "Advertir y no procesar"
]

# Opciones de cambio de fondo
BACKGROUND_TYPES = [
    "Color Sólido",
    "Degradado",
    "Imagen de Fondo"
]

GRADIENT_DIRECTIONS = [
    "Horizontal (Izq → Der)",
    "Vertical (Arr → Aba)",
    "Diagonal (↘)",
    "Diagonal (↙)",
    "Radial (Centro)"
]

# Los formatos que soportan transparencia ya están definidos arriba.

# Catálogo de modelos rembg -- cada entrada es un "perfil" autocontenido: además
# de file/url/folder (descarga, ver models_setup.py), declara "input_size" (lado
# del cuadrado NxN que espera el modelo como entrada). Esto es a propósito: el
# motor de inferencia (core/tabs/image_tools/rembg_engine.py) NO tiene ningún
# if/elif por nombre de modelo -- lee "input_size" de aquí y ya sabe cómo correr
# cualquier entrada de este diccionario. Agregar un modelo nuevo es agregar una
# entrada con su input_size correcto, no tocar el motor. Todos comparten el
# mismo contrato entrada/salida (RGB -> máscara de 1 canal, normalización
# ImageNet) porque son arquitecturas de segmentación de la misma familia --
# si algún día entra un modelo con un contrato distinto, es el momento de
# sumarle un campo nuevo aquí, no de volver a bifurcar el motor por nombre.
#
# "size_bytes" es el peso REAL del archivo a descargar, medido con un HEAD a su
# URL (Content-Length) contra los releases de GitHub/HuggingFace -- no una
# estimación. Sirve para avisar cuánto pesa ANTES de bajarlo, tanto en Ajustes >
# Modelos como en el diálogo de descarga que sale al elegir un modelo que no está
# instalado desde los popovers del Editor de Imagen (ver
# gui/widgets/model_download_prompt.py). Si algún día se cambia una URL por otra
# versión del mismo modelo, hay que volver a medir este número: un valor viejo no
# rompe la descarga (el porcentaje real sale del Content-Length de la respuesta),
# pero le miente al usuario en el diálogo. Los modelos de RMBG 2.0 marcados como
# gated (URL a una página de HuggingFace, no a un archivo) llevan el tamaño que
# declara la API de HuggingFace para ese archivo.
REMBG_MODEL_FAMILIES = {
    "Rembg Standard (U2Net)": {
        "isnet-general-use (Recomendado)": {
            "file": "isnet-general-use.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx",
            "folder": "rembg",
            "size_bytes": 178648008,
            "input_size": (1024, 1024)
        },
        "u2netp (Rápido)": {
            "file": "u2netp.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
            "folder": "rembg",
            "size_bytes": 4574861,
            "input_size": (320, 320)
        },
        "u2net (Alta Precisión)": {
            "file": "u2net.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net.onnx",
            "folder": "rembg",
            "size_bytes": 175997641,
            "input_size": (320, 320)
        },
        "u2net_human_seg (Humanos)": {
            "file": "u2net_human_seg.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx",
            "folder": "rembg",
            "size_bytes": 175997641,
            "input_size": (320, 320)
        },
        "isnet-anime (Anime)": {
            "file": "isnet-anime.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-anime.onnx",
            "folder": "rembg",
            "size_bytes": 176069933,
            "input_size": (1024, 1024)
        }
    },
    "BiRefNet (Next-Gen 2024)": {
        # --- MODELOS GENERALES ---
        "General (Estándar)": {
            "file": "birefnet-general.onnx",  # ✅ Nombre que rembg espera
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-general-epoch_244.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },
        "General Lite (Rápido)": {
            "file": "birefnet-general-lite.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-general-bb_swin_v1_tiny-epoch_232.onnx",
            "folder": "rembg",
            "size_bytes": 224005088,
            "input_size": (1024, 1024)
        },

        # --- ESPECIALIZADOS ---
        "Portrait (Retratos)": {
            "file": "birefnet-portrait.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-portrait-epoch_150.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },
        "DIS (Bordes Finos/Complejo)": {
            "file": "birefnet-dis.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-DIS-epoch_590.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },
        "COD (Objetos Camuflados)": {
            "file": "birefnet-cod.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-COD-epoch_125.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },
        "HRSOD (Alta Detección)": {
            "file": "birefnet-hrsod.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-HRSOD_DHU-epoch_115.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },

        # --- ALTA RESOLUCIÓN (HR) & MASIVOS ---
        "Massive (Entrenamiento Masivo)": {
            "file": "birefnet-massive.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-massive-TR_DIS5K_TR_TEs-epoch_420.onnx",
            "folder": "rembg",
            "size_bytes": 972666916,
            "input_size": (1024, 1024)
        },
        "HR General (4K/8K)": {
            "file": "birefnet-hr-general.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet_HR-general-epoch_130.onnx",
            "folder": "rembg",
            "size_bytes": 1098928953,
            "input_size": (1024, 1024)
        },
        "HR Matting (Recorte Ultra Fino)": {
            "file": "birefnet-hr-matting.onnx",  # ✅ Cambiado
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet_HR-matting-epoch_135.onnx",
            "folder": "rembg",
            "size_bytes": 1098928867,
            "input_size": (1024, 1024)
        }
    },

    # --- NUEVO BLOQUE: RMBG 2.0 (Descarga Manual) ---
    "RMBG 2.0 (BriaAI)": {
        "Standard (Automático)": {
            "file": "rmbg2_gatis.onnx",
            "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/bria-rmbg-2.0.onnx",
            "folder": "rmbg2",
            "size_bytes": 1024331469,
            "input_size": (1024, 1024)
        },
        "Standard (Manual)": {
            "file": "model.onnx",
            "url": "https://huggingface.co/briaai/RMBG-2.0/tree/main/onnx",
            "folder": "rmbg2",
            "size_bytes": 1024331469,
            "input_size": (1024, 1024)
        },
        "BnB4 (Recomendado)": {
            "file": "model_bnb4.onnx",
            "url": "https://huggingface.co/briaai/RMBG-2.0/tree/main/onnx",
            "folder": "rmbg2",
            "size_bytes": 355288046,
            "input_size": (1024, 1024)
        },
        "FP16 (Media)": {
            "file": "model_fp16.onnx",
            "url": "https://huggingface.co/briaai/RMBG-2.0/tree/main/onnx",
            "folder": "rmbg2",
            "size_bytes": 513576499,
            "input_size": (1024, 1024)
        },
        "Int8 (Rápido)": {
            "file": "model_int8.onnx",
            "url": "https://huggingface.co/briaai/RMBG-2.0/tree/main/onnx",
            "folder": "rmbg2",
            "size_bytes": 366087445,
            "input_size": (1024, 1024)
        },
        "Quantized": {
            "file": "model_quantized.onnx",
            "url": "https://huggingface.co/briaai/RMBG-2.0/tree/main/onnx",
            "folder": "rmbg2",
            "size_bytes": 366087549,
            "input_size": (1024, 1024)
        }
    },

    "InSPyReNet (Ultra High Resolution)": {
        "SwinB Plus Ultra (FP32)": {
            "file": "inspyrenet_ultra.onnx",
            "url": "https://huggingface.co/OS-Software/InSPyReNet-SwinB-Plus-Ultra-ONNX/resolve/main/onnx/model.onnx?download=true",
            "folder": "inspyrenet",
            "size_bytes": 395316574,
            "input_size": (1024, 1024)
        },
        "SwinB Plus Ultra (FP16)": {
            "file": "inspyrenet_ultra_fp16.onnx",
            "url": "https://huggingface.co/OS-Software/InSPyReNet-SwinB-Plus-Ultra-ONNX/resolve/main/onnx/model_fp16.onnx?download=true",
            "folder": "inspyrenet",
            "size_bytes": 199133027,
            "input_size": (1024, 1024)
        }
    }
}

UPSCALING_TOOLS = {
    "Waifu2x": {
        "name": "Waifu2x",
        "folder": "waifu2x",
        # exe/url por plataforma -- ver core/setup/models_setup.py:_platform_value().
        # Mismo release (20250915), un asset .zip distinto por SO en GitHub.
        "exe": {
            "windows": "waifu2x-ncnn-vulkan.exe",
            "macos": "waifu2x-ncnn-vulkan",
            "linux": "waifu2x-ncnn-vulkan",
        },
        "url": {
            "windows": "https://github.com/nihui/waifu2x-ncnn-vulkan/releases/download/20250915/waifu2x-ncnn-vulkan-20250915-windows.zip",
            "macos": "https://github.com/nihui/waifu2x-ncnn-vulkan/releases/download/20250915/waifu2x-ncnn-vulkan-20250915-macos.zip",
            "linux": "https://github.com/nihui/waifu2x-ncnn-vulkan/releases/download/20250915/waifu2x-ncnn-vulkan-20250915-linux.zip",
        },
        "size_bytes": {
            "windows": 35497352,
            "macos": 41706129,
            "linux": 36658685,
        },
    },
    "SRMD": {
        "name": "SRMD",
        "folder": "srmd",
        "exe": {
            "windows": "srmd-ncnn-vulkan.exe",
            "macos": "srmd-ncnn-vulkan",
            "linux": "srmd-ncnn-vulkan",
        },
        "url": {
            "windows": "https://github.com/nihui/srmd-ncnn-vulkan/releases/download/20220728/srmd-ncnn-vulkan-20220728-windows.zip",
            "macos": "https://github.com/nihui/srmd-ncnn-vulkan/releases/download/20220728/srmd-ncnn-vulkan-20220728-macos.zip",
            "linux": "https://github.com/nihui/srmd-ncnn-vulkan/releases/download/20220728/srmd-ncnn-vulkan-20220728-ubuntu.zip",
        },
        "size_bytes": {
            "windows": 19208707,
            "macos": 24612116,
            "linux": 19716383,
        },
    },
    "Upscayl": {
        "name": "Upscayl (Global Engine)",
        "folder": "upscayl",
        "exe": {
            "windows": "upscayl-bin.exe",
            "macos": "upscayl-bin",
            "linux": "upscayl-bin",
        },
        "url": {
            "windows": "https://github.com/upscayl/upscayl-ncnn/releases/download/20251207-174704/upscayl-bin-20251207-174704-windows.zip",
            "macos": "https://github.com/upscayl/upscayl-ncnn/releases/download/20251207-174704/upscayl-bin-20251207-174704-macos.zip",
            "linux": "https://github.com/upscayl/upscayl-ncnn/releases/download/20251207-174704/upscayl-bin-20251207-174704-linux.zip",
        },
        "size_bytes": {
            "windows": 2421760,
            "macos": 9338240,
            "linux": 3952825,
        },
        "models_size_bytes": 319059567,
        # Modelos (custom-models): mismo zip para los tres SO, no cambia.
        "models_url": "https://github.com/upscayl/custom-models/archive/refs/heads/main.zip"
    }
}

# --- NOTA: soporte EPS/PS en ImageConverter ---
# EPS/PS (PostScript puro, pre-PDF) necesita un intérprete real -- no existe
# equivalente puro-pip multiplataforma (a diferencia de SVG/PDF/AI, que se
# resuelven con resvg_py/pypdfium2 sin binarios externos). En Windows, Ghostscript
# es una dependencia OPCIONAL (Ajustes > Dependencias, no se descarga sola) --
# ver core/setup/ghostscript_setup.py para el detalle de cómo se instala (el
# release oficial es un instalador NSIS, no un zip portable, y desde la 10.01.0
# no admite instalación silenciosa -- se extrae con 7-Zip sin ejecutarlo) y
# core/tabs/image_tools/image_converter.py::_load_eps_ps para la conversión en
# sí (EPS/PS -> PDF temporal vía Ghostscript, reusando el renderizador PDF ya
# existente).
#
# En Linux/macOS no hay build bundleable (Linux: paquete Snap, no un tarball
# suelto; macOS: sin build precompilado) -- en vez de bundlear, se detecta un
# Ghostscript ya instalado por el propio usuario (binario `gs`, típicamente a
# un `apt install ghostscript` / `brew install ghostscript` de distancia,
# ver ghostscript_setup.py::_find_system_gs/get_install_info) y se habilita
# EPS/PS ahí si existe. La tarjeta de Ajustes > Dependencias (deps_page.py::
# GhostscriptCardPanel) le sugiere al usuario el comando correcto según el SO
# y el gestor de paquetes detectado, con un botón para copiarlo y otro para
# re-verificar tras instalarlo a mano (no hay forma de automatizar la
# instalación en sí: brew/apt piden sudo/interacción de terminal).

# --- MAPEOC DE NOMBRES AMIGABLES PARA UPSCAYL ---
# Upscayl es deliberadamente "más global" que solo el repo custom-models -- DowP1 ya
# sumaba modelos de otras 2 fuentes (ver setup.pyc decompilado,
# check_and_download_upscaling_tools/_UPSCAYL_LEGACY_MODEL_SOURCES en
# core/setup/models_setup.py): realesrgan-x4plus/-anime vienen del release oficial de
# xinntao/Real-ESRGAN, DF2K_x4/DF2K_JPEG_x4 del release oficial de nihui/realsr-ncnn-
# vulkan. NO son parte de custom-models -- por eso "faltaban" ahí. Las variantes
# realesr-animevideov3-x2/x3 quedan afuera a propósito: DowP1 las purga por
# inestabilidad conocida (sanitize_upscayl_models -- ver _sanitize_upscayl_models en
# models_setup.py), solo se ofrece la x4.
# Modelos que Upscayl necesita y que NO vienen en el repo custom-models -- se bajan
# de los releases oficiales de Real-ESRGAN/RealSR (ver _download_upscayl_legacy_models
# en core/setup/models_setup.py, que es quien los consume). Cada entrada es
# (nombre, url, archivo-canario, peso real en bytes): el canario es el archivo que,
# si ya está en disco, permite saltarse esa descarga entera. Un solo URL por fuente
# alcanza para los 3 SO: los .bin/.param son datos de pesos, idénticos sin importar
# qué build del binario los acompañe.
UPSCAYL_LEGACY_MODEL_SOURCES = [
    ("Real-ESRGAN", "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip", "realesrgan-x4plus.bin", 45474481),
    ("RealSR", "https://github.com/nihui/realsr-ncnn-vulkan/releases/download/20220728/realsr-ncnn-vulkan-20220728-windows.zip", "DF2K_x4.bin", 64005701),
]

UPSCAYL_MODELS_MAP = {
    "realesrgan-x4plus": "Real-ESRGAN (General / Fotografía)",
    "realesrgan-x4plus-anime": "Real-ESRGAN (Anime / Ilustración)",
    "realesr-animevideov3-x4": "Anime Video V3 (x4)",
    "RealESRGAN_General_x4_v3": "Real-ESRGAN V3 (Ligero y Rápido)",
    "RealESRGAN_General_WDN_x4_v3": "Real-ESRGAN V3 WDN (Red Profunda)",
    "4xHFA2k": "HFA2k (Texturas de Alta Frecuencia)",
    "4xLSDIR": "LSDIR (Fotografía Realista)",
    "4xLSDIRCompactC3": "LSDIR Compacto (Procesamiento Rápido)",
    "4xLSDIRplusC": "LSDIR PlusC (Alta Fidelidad)",
    "4xNomos8kSC": "Nomos8k (Detalles a Escala 8k)",
    "4x_NMKD-Siax_200k": "NMKD Siax (Universal / Calidad JPEG)",
    "4x_NMKD-Superscale-SP_178000_G": "NMKD Superscale (Fotos sin Artefactos)",
    "uniscale_restore": "Uniscale Restore (Restauración de Daños)",
    "unknown-2.0.1": "The Unknown (Experimental / Nitidez Extrema)",
    "DF2K_x4": "RealSR (Detalle de Texturas)",
    "DF2K_JPEG_x4": "RealSR JPEG (Reduce Compresión)",
}

# --- CONSTANTES DE REESCALADO (IA) ---

# Escalas y niveles de ruido REALES de cada motor. No salen de la documentación:
# se sacaron corriendo cada binario con -h y después probando valor por valor
# contra una imagen de prueba, porque las dos fuentes se contradicen y el binario
# es el que manda. Lo que se encontró:
#
#   - upscayl-bin: su -h dice "custom output scale (can be 2, 3, 4)", pero es
#     mentira -- acepta cualquier entero >= 1 (probados 1,2,3,4,5,6,7,8,16,32,
#     todos devuelven la imagen al tamaño exacto pedido). Internamente repite
#     pasadas del modelo x4 hasta pasarse y remuestrea hacia abajo, por eso las
#     escalas altas cuestan varias pasadas. El 0 sí es inválido: el proceso
#     termina con código 0 pero deja un archivo corrupto.
#   - waifu2x-ncnn-vulkan: 1/2/4/8/16/32 y nada más -- el 3x que la app venía
#     ofreciendo para los tres motores por igual moría con "invalid scale
#     argument". Atencion con el 1x (solo denoise, sin agrandar): necesita los
#     modelos noiseN_model.param, que SOLO trae models-cunet -- las dos carpetas
#     upconv_7_* traen únicamente noiseN_scale2.0x_model, así que ahí 1x falla.
#     Por eso las escalas van por modelo y no por motor.
#   - srmd-ncnn-vulkan: 2/3/4 (lo único que ya estaba bien) y ruido -1 a 10 --
#     la app solo ofrecía hasta 3, dejando 7 niveles afuera.

UPSCAYL_SCALES = ["1x", "2x", "3x", "4x", "6x", "8x", "16x"]

_WAIFU2X_SCALES = ["1x", "2x", "4x", "8x", "16x", "32x"]
# Sin 1x: ver arriba (upconv_7_* no trae modelos de solo-denoise).
_WAIFU2X_SCALES_UPCONV = ["2x", "4x", "8x", "16x", "32x"]

SRMD_SCALES = ["2x", "3x", "4x"]

# Etiquetas de -n. La escala de Waifu2x es corta y con nombre; la de SRMD llega a
# 10 y es un continuo, así que solo se nombran los extremos.
WAIFU2X_DENOISE_LEVELS = ["-1 (Ninguna)", "0 (Baja)", "1 (Media)", "2 (Alta)", "3 (Máxima)"]
SRMD_DENOISE_LEVELS = (
    ["-1 (Ninguna)", "0 (Baja)"] + [str(n) for n in range(1, 10)] + ["10 (Máxima)"]
)

WAIFU2X_MODELS = {
    "CU-Net (Alta Calidad)": {
        "model": "models-cunet",
        "scales": _WAIFU2X_SCALES
    },
    "Anime Style Art (Clásico)": {
        "model": "models-upconv_7_anime_style_art_rgb",
        "scales": _WAIFU2X_SCALES_UPCONV
    },
    "Photo (Fotos Reales)": {
        "model": "models-upconv_7_photo",
        "scales": _WAIFU2X_SCALES_UPCONV
    },
}

SRMD_MODELS = {
    "Estándar (General)": {
        "model": "models-srmd",
        "scales": SRMD_SCALES
    }
}